import React from 'react'
import ReactDOM from 'react-dom/client'
// NOTE: leafletFix removed — using window.L (Leaflet via CDN in index.html)
// If you still need npm leaflet for other reasons, add: import './lib/leafletFix'
import './index.css'
import AuditoriaRutas from './pages/AuditoriaRutas'
import { ThemeProvider } from './context/ThemeContext'

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <ThemeProvider>
      <AuditoriaRutas />
    </ThemeProvider>
  </React.StrictMode>
)