import { useMemo, useState } from 'react'
import type { SummaryRow } from '../../types/auditoria'
import {
  PageShell, ScrollArea, Toolbar, SearchInput, FilterPills,
  Badge, Btn, CopyBtn, Divider, EmptyState,
  C, T
} from '../../ui/DS'

interface Props {
  rows: SummaryRow[]
  onResolve: (iso: string, aKey: string | null, tipo: string, resolve: boolean) => void
  onFlag:    (iso: string, aKey: string | null, tipo: string, flag: boolean) => void
  resolvedConflicts: Set<string>
  flaggedConflicts:  Set<string>
  resolvedRisk:      Set<string>
  flaggedRisk:       Set<string>
}

const STATUS_ORDER: Record<string, number> = { pendiente: 0, alerta: 1, resuelto: 2, aprobado: 2 }

function escHtml(s: string) {
  return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
}

function exportXLSX(rows: SummaryRow[]) {
  if (!rows.length) return
  const W = (window as any).XLSX
  if (!W) { alert('XLSX no disponible'); return }
  const wb = W.utils.book_new()
  const wsData = [['ISO', 'Vehículo', 'Dirección', 'Observación', 'Detalle', 'Estado']]
  for (const r of rows) {
    wsData.push([r.iso, r.veh, r.dir || '', r.obs || '', r.detalle || '',
      r.status === 'resuelto' ? 'Resuelto' : r.status === 'aprobado' ? 'Aprobado' : r.status === 'alerta' ? 'Alerta' : 'Pendiente'])
  }
  const ws = W.utils.aoa_to_sheet(wsData)
  ws['!cols'] = [{wch:14},{wch:20},{wch:45},{wch:20},{wch:55},{wch:14}]
  W.utils.book_append_sheet(wb, ws, 'Alertas')
  W.writeFile(wb, 'resumen_alertas.xlsx')
}

function copyToClipboard(rows: SummaryRow[]) {
  if (!rows.length) return
  const hS = 'border:1px solid #000;padding:6px 10px;font-weight:bold;background:#0051BA;color:#FFDA1A;font-family:Arial,sans-serif;font-size:11px;'
  const tS = 'border:1px solid #000;padding:5px 10px;background:#fff;color:#000;font-family:Arial,sans-serif;font-size:11px;'
  let rich = `<table style="border-collapse:collapse"><tr><th style="${hS}">ISO</th><th style="${hS}">Vehículo</th><th style="${hS}">Dirección</th><th style="${hS}">Observación</th><th style="${hS}">Detalle</th><th style="${hS}">Estado</th></tr>`
  let plain = 'ISO\tVehículo\tDirección\tObservación\tDetalle\tEstado\n'
  for (const r of rows) {
    const estado = r.status === 'resuelto' ? 'Resuelto' : r.status === 'aprobado' ? 'Aprobado' : r.status === 'alerta' ? 'Alerta' : 'Pendiente'
    rich += `<tr><td style="${tS}font-weight:700">${escHtml(r.iso)}</td><td style="${tS}">${escHtml(r.veh)}</td><td style="${tS}">${escHtml(r.dir||'')}</td><td style="${tS}">${escHtml(r.obs||'')}</td><td style="${tS}">${escHtml(r.detalle||'')}</td><td style="${tS}">${estado}</td></tr>`
    plain += `${r.iso}\t${r.veh}\t${r.dir||''}\t${r.obs||''}\t${r.detalle||''}\t${estado}\n`
  }
  rich += '</table>'
  try {
    navigator.clipboard.write([new ClipboardItem({ 'text/html': new Blob([rich], { type:'text/html' }), 'text/plain': new Blob([plain], { type:'text/plain' }) })])
  } catch { navigator.clipboard.writeText(plain) }
}

type StatusFilter = 'all' | 'pendiente' | 'alerta' | 'resuelto'
type TypeFilter   = 'all' | 'geo' | 'fuera' | 'ambos'

export default function TabSummary({ rows, onResolve, onFlag }: Props) {
  const [search, setSearch]           = useState('')
  const [typeFilter, setTypeFilter]   = useState<TypeFilter>('all')
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('all')
  const [sortCol, setSortCol]         = useState<string | null>(null)
  const [sortDir, setSortDir]         = useState<'asc'|'desc'>('asc')

  function toggleSort(col: string) {
    if (sortCol === col) setSortDir(d => d === 'asc' ? 'desc' : 'asc')
    else { setSortCol(col); setSortDir('asc') }
  }

  const visible = useMemo(() => {
    let r = rows.filter(row => {
      if (typeFilter !== 'all' && row.tipo !== typeFilter) return false
      if (statusFilter !== 'all') {
        const s = row.status === 'aprobado' ? 'resuelto' : row.status
        if (s !== statusFilter) return false
      }
      if (search) {
        const lo = search.toLowerCase()
        return row.iso.toLowerCase().includes(lo) || row.veh.toLowerCase().includes(lo) || (row.dir||'').toLowerCase().includes(lo)
      }
      return true
    })
    if (sortCol) {
      r = [...r].sort((a, b) => {
        const va = String((a as any)[sortCol] ?? '').toLowerCase()
        const vb = String((b as any)[sortCol] ?? '').toLowerCase()
        return sortDir === 'asc' ? va.localeCompare(vb, 'es') : vb.localeCompare(va, 'es')
      })
    } else {
      r = [...r].sort((a, b) => (STATUS_ORDER[a.status]||0) - (STATUS_ORDER[b.status]||0))
    }
    return r
  }, [rows, search, sortCol, sortDir, typeFilter, statusFilter])

  const nGeo   = rows.filter(r => r.tipo === 'geo').length
  const nFuera = rows.filter(r => r.tipo === 'fuera').length
  const nAmbos = rows.filter(r => r.tipo === 'ambos').length
  const nPend  = rows.filter(r => r.status === 'pendiente').length

  if (!rows.length) return <EmptyState icon="📊" message="Carga un plan y ejecuta los análisis para ver el resumen aquí." />

  const th: React.CSSProperties = {
    padding: '7px 12px', textAlign: 'left', color: C.textFaint,
    fontWeight: 600, fontSize: T.base, cursor: 'pointer', whiteSpace: 'nowrap',
    borderBottom: `1px solid ${C.border}`,
  }
  const td: React.CSSProperties = {
    padding: '6px 12px', fontSize: T.base,
    borderBottom: `1px solid ${C.borderSoft}`,
  }

  const COLS = [
    { key: 'iso',     label: 'ISO' },
    { key: 'veh',     label: 'Vehículo' },
    { key: 'dir',     label: 'Dirección' },
    { key: 'obs',     label: 'Observación' },
    { key: 'detalle', label: 'Detalle' },
    { key: 'status',  label: 'Estado' },
  ]

  return (
    <PageShell>
      <Toolbar
        left={
          <>
            <span style={{ fontSize: T.base, color: C.textMuted }}>
              {rows.length} alertas · <span style={{ color: C.orange, fontWeight: 700 }}>{nPend} pendientes</span>
            </span>
            <Divider vertical />
            <FilterPills<TypeFilter>
              value={typeFilter}
              onChange={setTypeFilter}
              options={[
                { key: 'all',   label: `Todos (${rows.length})` },
                { key: 'geo',   label: `CI (${nGeo})` },
                { key: 'fuera', label: `FR (${nFuera})` },
                { key: 'ambos', label: `FR+CI (${nAmbos})` },
              ]}
            />
            <Divider vertical />
            <FilterPills<StatusFilter>
              value={statusFilter}
              onChange={setStatusFilter}
              options={[
                { key: 'all',       label: 'Todos' },
                { key: 'pendiente', label: '⏳ Pendiente' },
                { key: 'alerta',    label: '⚠ Alerta' },
                { key: 'resuelto',  label: '✓ Resuelto' },
              ]}
            />
          </>
        }
        right={
          <>
            <SearchInput value={search} onChange={setSearch} placeholder="Buscar ISO, veh, dir…" width={160} />
            <Btn variant="blue" size="sm" onClick={() => copyToClipboard(visible)}>📋 Copiar</Btn>
            <Btn variant="success" size="sm" onClick={() => exportXLSX(visible)}>⬇ Excel</Btn>
          </>
        }
      />

      <ScrollArea style={{ overflowX: 'auto' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: T.base, minWidth: 700 }}>
          <thead style={{ position: 'sticky', top: 0, zIndex: 10, background: 'var(--ar-bg-card)' }}>
            <tr>
              <th style={{ ...th, width: 32, textAlign: 'center', cursor: 'default' }}>#</th>
              {COLS.map(col => (
                <th key={col.key} style={th} onClick={() => toggleSort(col.key)}>
                  {col.label}
                  {sortCol === col.key && <span style={{ marginLeft: 4 }}>{sortDir === 'asc' ? '↑' : '↓'}</span>}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {visible.map((r, i) => {
              const isRes = r.status === 'resuelto' || r.status === 'aprobado'
              const isFlg = r.status === 'alerta'

              const tipoEl = r.tipo === 'fuera'
                ? <Badge variant="medium">Fuera de Ruta</Badge>
                : r.tipo === 'ambos'
                  ? <Badge variant="high">FR + CI</Badge>
                  : <Badge variant="blue">C. Incorrecta</Badge>

              const statusEl = isRes
                ? <span style={{ color: C.green, fontWeight: 700, fontSize: T.base }}>✓ {r.status === 'aprobado' ? 'Aprobado' : 'Resuelto'}</span>
                : isFlg
                  ? <span style={{ color: C.red, fontWeight: 700, fontSize: T.base }}>⚠ Alerta</span>
                  : <span style={{ color: C.orange, fontWeight: 700, fontSize: T.base }}>⏳ Pendiente</span>

              return (
                <tr key={r.iso + i}
                  style={{
                    opacity: isRes ? 0.4 : 1,
                    background: i % 2 === 0 ? 'transparent' : 'var(--ar-bg-hover)',
                  }}>
                  <td style={{ ...td, textAlign: 'center', color: C.textFaint, fontSize: T.sm }}>{i + 1}</td>

                  {/* ISO — clickable to copy */}
                  <td style={{ ...td, fontWeight: 700 }}>
                    <button onClick={() => navigator.clipboard.writeText(r.iso).catch(() => {})}
                      style={{ background: 'none', border: 'none', cursor: 'pointer', color: C.blue, fontWeight: 700, fontSize: T.base, fontFamily: T.fontMono, padding: 0 }}
                      title="Copiar ISO"
                    >{r.iso}</button>
                  </td>

                  <td style={{ ...td, color: C.textMuted, maxWidth: 140, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }} title={r.veh}>{r.veh}</td>
                  <td style={{ ...td, color: C.textFaint, maxWidth: 200, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }} title={r.dir}>{r.dir || '—'}</td>

                  <td style={td}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                      {tipoEl}
                      <span style={{ color: C.textMuted, fontSize: T.sm }}>{r.obs}</span>
                    </div>
                  </td>

                  <td style={{ ...td, color: C.textFaint, maxWidth: 200, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }} title={r.detalle}>{r.detalle || '—'}</td>
                  <td style={{ ...td, whiteSpace: 'nowrap' }}>{statusEl}</td>
                </tr>
              )
            })}
          </tbody>
        </table>
        {visible.length === 0 && (
          <div style={{ textAlign: 'center', color: C.textFaint, padding: '40px 0', fontSize: T.md }}>Sin resultados</div>
        )}
      </ScrollArea>
    </PageShell>
  )
}
